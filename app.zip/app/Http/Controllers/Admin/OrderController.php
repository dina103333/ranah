<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\DriectOrderRequest;
use App\Jobs\SendFCMNotificationJob;
use App\Models\Driver;
use App\Models\Order;
use App\Models\OrderProduct;
use App\Models\Product;
use App\Models\Setting;
use App\Models\Shop;
use App\Models\Store;
use App\Models\StoreProduct;
use App\Models\User;
use Facade\FlareClient\View;
use Illuminate\Http\Request;
use SebastianBergmann\CodeCoverage\Report\Xml\Totals;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $orders = Order::select('*',\DB::raw("(DATE_FORMAT(created_at,'%Y-%m-%d')) as created_date"),\DB::raw("(DATE_FORMAT(updated_at,'%Y-%m-%d')) as delivered_date"))->with('user:id,name','driver:id,name','shop:id,area_id','shop.area:id,name','store:id,name')->paginate(10);
        $drivers = Driver::where('status','تفعيل')->select('id','name')->get();
        return view('admin.order.index',compact('orders','drivers'));
    }

    public function getOrders()
    {
        $orders = Order::select('*',\DB::raw("(DATE_FORMAT(created_at,'%Y-%m-%d')) as created_date"),\DB::raw("(DATE_FORMAT(updated_at,'%Y-%m-%d')) as delivered_date"))->with('user:id,name','driver:id,name','shop:id,area_id','shop.area:id,name','store:id,name')->get();
        return datatables($orders)->make(true);
    }


    public function assignDriver(Request $request){
        Order::whereIn('id',$request->arr)->update([
            'driver_id' => $request->driver_id,
            'status' => 'في الطريق'
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $stores = Store::where('status', 'تفعيل')->get();
        return view('admin.direct_order.create',compact('stores'));
    }

    public function getStorUsers($store_id){
        $users = User::where('store_id', $store_id)->select('id','name')->get();
        $products = Product::where('status','تفعيل')->whereHas('stores',function($q) use($store_id){
            $q->where('stores_products.store_id', $store_id)->where('stores_products.wholesale_quantity','!=',0)
            ->where('stores_products.sell_wholesale_price','!=',null)
            ->where('stores_products.wholesale_quantity','!=',null);
        })
        ->with('stores',function($q) use($store_id){
            $q->where('stores_products.store_id', $store_id)
            ->where('stores_products.wholesale_quantity','!=',0)
            ->where('stores_products.sell_wholesale_price','!=',null)
            ->where('stores_products.wholesale_quantity','!=',null)
            ->select('stores.id');
        })->select('id','name')->get();
        return response()->json(['users' => $users, 'products' => $products]);
    }

    public function getProductDetails(Request $request,$product_id){
        $product_details = StoreProduct::where('product_id', $product_id)
                                        ->where('store_id', $request->store_id)
                                        ->join('products','products.id','stores_products.product_id')->first();
        return  response()->json($product_details);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(DriectOrderRequest $request)
    {
        $products = array_filter($request->products);

        if(empty($products)  || (empty(array_filter($request->wholesale_quantity)) && empty(array_filter($request->unit_quantity))  )){
            return redirect()->back()->with('error','يجب اخنيار المنتجات مع تحديد كيمه لها');
        }
        $user = User::where('id',$request->user_id)->first();
        $store = Store::where('id',$request->store_id)->first();
        $order = Order::create([
            'shop_id'       => $user->shop_id,
            'store_id'      => $request->store_id,
            'sub_total'     => 0,
            'total'         => 0,
            'distance'      => 0,
            'fee'           => 0,
            'status'        => 'معلق',
            'type'          => 'مباشر',
            'user_id'       => $request->user_id,
        ]);
         $this->addOrderProducts($request,$order,$store,$products);
        return View('admin.order.show',compact('order'));
    }

    public function addOrderProducts($request,$order,$store,$products){
        $wholesale_quantity = array_filter($request->wholesale_quantity, fn ($value) => !is_null($value));
        $unit_quantity = array_filter($request->unit_quantity, fn ($value) => !is_null($value));
        $total=[];
        foreach($products as $key=>$product){
            $store_product = StoreProduct::where('product_id',$product)->where('store_id',$store->id)->first();
            $product_data = Product::where('id',$product)->select('id','wholesale_quantity_units')->first();
            if($store_product->max_limit !=0 ){
                if($store_product->lower_limit > $wholesale_quantity[$key] || $store_product->max_limit < $wholesale_quantity[$key] ){
                    OrderProduct::where('order_id',$order->id)->delete();
                    $order->delete();
                    return response()->json(['status'=>false,'message'=>'لا يمكن الطلب بهذه الكميه علما بأن اقصى كميه متاحه واقل كميه من ال'.$product->name . 'هى '.$store_product->lower_limit .'و'.$store_product->max_limit]);
                }
            }
            $products = OrderProduct::create([
                'order_id'                       => $order->id,
                'product_id'                     => $product,
                'shop_id'                        => $order->shop_id,
                'current_unit_quantity'          => $unit_quantity[$key] ,
                'current_wholesale_quantity'     => $wholesale_quantity[$key] ,
                'past_unit_quantity'             => $unit_quantity[$key] ,
                'past_wholesale_quantity'        => $wholesale_quantity[$key] ,
                'unit_price'                     => $store_product->sell_item_price,
                'wholesale_price'                => $store_product->sell_wholesale_price,
                'total'                          => ($wholesale_quantity[$key]  * $store_product->sell_wholesale_price) + ($unit_quantity[$key] *$store_product->sell_item_price ),
            ]);
            $total[]= $products->total;
            $order->update(['sub_total'=>array_sum($total) ,'total' => array_sum($total)]);
            if($wholesale_quantity != 0){
                $store_product->update([
                    'wholesale_quantity' => $store_product->wholesale_quantity - $wholesale_quantity[$key] ,
                    'unit_quantity' =>  $store_product->unit_quantity - ($wholesale_quantity[$key]  * $product_data->wholesale_quantity_units),
                ]);
            }else{
                $store_product->update([
                    'wholesale_quantity' => $store_product->wholesale_quantity - intval(($unit_quantity[$key] /$product_data->wholesale_quantity_units)),
                    'unit_quantity' => $store_product->unit_quantity - $unit_quantity[$key] ,
                ]);
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request,Order $order)
    {
        $order = Order::with('shop:id,name','user:id,name','store:id,name','products')->where('id',$order->id)->first();
        $status = Order::getEnumValues('orders','status');
        if($request->ajax()){
            $order = Order::with('shop:id,name','user:id,name','store:id,name','products')->where('id',$request->id)->first();
            return View('admin.order.table',compact('order','status'));
        }
        return View('admin.order.show',compact('order','status'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function edit(Order $order)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Order $order)
    {
        //
    }

    public function changeStatus(Request $request){
        $order= Order::where('id',$request->order_id)->first();
        $order->update([
            'status'=>$request->status
        ]);
        $response =  $this->updateOrderProducts($request,$order);
        if($response['status'] == true ){
            $total = $response['total'];
        }else{
            return response()->json(['status'=> false , 'message'=>$response['message']]);
        }
        $order->update(['sub_total'=>array_sum($total) ,'total' => array_sum($total) + ($order->fee * $order->distance)]);
        $type = 'order_status';
        $title = 'اشعار بحاله الطلب';
        $body = 'تم تغيير حاله الطلب الى '.$order->status;
        $id = $order->id;
        $image = url('/storage/files/logo.png') ;
        $devices = User::where('id',$order->user_id)->where('type','اونلاين')->pluck('device_token')->toArray();
        if(count($devices) > 0)
            dispatch(new SendFCMNotificationJob($devices, $title, $body,$type,$id,null,$image));
        return response()->json(['status'=>true ,'message'=>'تم تعديل الطلب بنجاح']);
    }

    public function confirmOrder(Request $request){
        $order= Order::where('id',$request->order_id)->first();
        $order->update([
            'status'=>'تم التسليم',
            'total' => $request->total
        ]);
        $this->updateOrderProducts($request,$order);
        return response()->json(['status'=>true ,'message'=>'تم تعديل الطلب بنجاح']);
    }

    public function updateOrderProducts($request,$order){
        $total=[];
        foreach($request->wholesale_quantity as $key=>$quantity){
            $order_product = OrderProduct::where('order_id',$request->order_id)->where('product_id',$quantity[0])->first();
            $store_product = StoreProduct::where('store_id', $order->store_id)->where('product_id',$order_product->product_id)->first();
            $product = Product::where('id',$quantity[0])->select('id','wholesale_quantity_units')->first();
            $min_quantity = $store_product->lower_limit ;
            $max_quantity = $store_product->max_limit;
            if($max_quantity != 0){
                if($min_quantity > $quantity[1] || $max_quantity < $quantity[1]){
                    return ['status'=>false , 'message'=>'لا يمكن طلب هذه الكميه من المنتج برجاء التأكد من اقل كميه واقصى كميه يمكن طلبها من المخزن'];
                }
            }
            $order_product->update([
                'current_unit_quantity'      => $request->unit_quantity[$key][1],
                'current_wholesale_quantity' => $quantity[1],
                'past_unit_quantity'         => $order_product->current_unit_quantity,
                'past_wholesale_quantity'    => $order_product->current_wholesale_quantity,
                'total'                      => ($order_product->wholesale_price * $quantity[1]) + ($order_product->unit_price * $request->unit_quantity[$key][1])
            ]);
            $total[]= $order_product->total;

            if($order_product->current_wholesale_quantity > $order_product->past_wholesale_quantity){
                $wholesale_quantity = $order_product->current_wholesale_quantity - $order_product->past_wholesale_quantity;
                $store_product->update([
                    'wholesale_quantity' => $store_product->wholesale_quantity - $wholesale_quantity,
                    'unit_quantity' => $store_product->unit_quantity - ($wholesale_quantity * $product->wholesale_quantity_units)
                ]);
            }else if($order_product->current_wholesale_quantity < $order_product->past_wholesale_quantity){
                $wholesale_quantity = $order_product->past_wholesale_quantity - $order_product->current_wholesale_quantity ;
                $store_product->update([
                    'wholesale_quantity' => $store_product->wholesale_quantity + $wholesale_quantity,
                    'unit_quantity' => $store_product->unit_quantity + ($wholesale_quantity * $product->wholesale_quantity_units)
                ]);
            }


            if($order_product->current_unit_quantity > $order_product->past_unit_quantity){
                $unit_quantity = $order_product->current_unit_quantity - $order_product->past_unit_quantity;
                $store_product->update([
                    'unit_quantity' => $store_product->unit_quantity - $unit_quantity,
                    'wholesale_quantity' => $store_product->wholesale_quantity - intval($unit_quantity/$product->wholesale_quantity_units),
                ]);
            }else if($order_product->current_unit_quantity < $order_product->past_unit_quantity){
                $unit_quantity = $order_product->past_unit_quantity - $order_product->current_unit_quantity;
                $store_product->update([
                    'unit_quantity' => $store_product->unit_quantity + $unit_quantity,
                    'wholesale_quantity' => $store_product->wholesale_quantity + intval($unit_quantity/$product->wholesale_quantity_units),
                ]);
            }
        }
        return ['status'=>true , 'total'=>$total];
        // return $total;
    }


    public function deliveredOrder(Request $request){
        $order = Order::where('id',$request->id)->first();
        $order->update(['delivered_from_store'=>true]);
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function destroy(Order $order)
    {
        $order = Order::where('id',$order->id)->first();
        $order_products =OrderProduct::where('order_id',$order->id)->get();
        foreach($order_products as $product){
            $store_product = StoreProduct::where('product_id',$product->product_id)->where('store_id',$order->store_id)->first();
            $product_data = Product::where('id',$product->product_id)->first();
            $store_product->update([
                'wholesale_quantity' => ($store_product->wholesale_quantity + $product->current_wholesale_quantity) +
                intval(($store_product->wholesale_quantity + ($product->current_unit_quantity / $product_data->wholesale_quantity_units))),
                'unit_quantity' => ($store_product->unit_quantity + ($product->current_wholesale_quantity * $product_data->wholesale_quantity_units)) +
                ($store_product->unit_quantity + $product->current_unit_quantity)
                ,
            ]);
        }
        $order->update(['status'=>'تم الالغاء']);

    }

    public function printBill($order)
    {
        $order = Order::with('shop:id,name,address,area_id','shop.area:id,name','user:id,name,mobile_number','store:id,name','products')->where('id',$order)->first();
        $status = Order::getEnumValues('orders','status');
        return view('admin.order.bill',compact('order','status'));
    }
}
