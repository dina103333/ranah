<script>
    var hostUrl = "/assets/";
</script>
<script src="/assets/plugins/global/plugins.bundle.js"></script>
<script src="/assets/js/scripts.bundle.js"></script>
<script src="/assets/plugins/custom/fullcalendar/fullcalendar.bundle.js"></script>
<script src="/assets/js/custom/widgets.js"></script>
<script src="/assets/js/custom/apps/chat/chat.js"></script>
<script src="/assets/js/custom/modals/create-app.js"></script>
<script src="/assets/js/custom/modals/upgrade-plan.js"></script>


<script src="/assets/plugins/custom/datatables/datatables.bundle.js"></script>
<script src="/assets/js/custom/apps/invoices/create.js"></script>
<script src="/assets/js/jQuery.print.min.js"></script>

<script src="/assets/js/custom/account/settings/signin-methods.js"></script>
<script src="/assets/js/custom/account/settings/profile-details.js"></script>
<script src="/assets/js/custom/account/settings/deactivate-account.js"></script>

<script src="https://www.gstatic.com/firebasejs/7.17.1/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.17.1/firebase-analytics.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.17.1/firebase-database.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.17.1/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.17.1/firebase-firestore.js"></script>

<script>
    const firebaseConfig = {
        apiKey: "AIzaSyBJ_4Efr1aDXQUfm7QeIWXn0-Sd8CdhLb4",
        authDomain: "gold-47e14.firebaseapp.com",
        databaseURL: "https://gold-47e14-default-rtdb.firebaseio.com",
        projectId: "gold-47e14",
        storageBucket: "gold-47e14.appspot.com",
        messagingSenderId: "885142091316",
        appId: "1:885142091316:web:56948478446d871e97bc61",
        measurementId: "G-HPCTCVNVXF"
    };
    firebase.initializeApp(firebaseConfig);
</script>


<script type="text/javascript">
    var statistics = firebase.database().ref("notifications/1");
    statistics.on('value', function(snapshot) {
        if (snapshot.val() != 0) {
            const audio = new Audio("{{ url('notify.mp3') }}");
            audio.play();
            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "{{ getLocal() == 'ar' ? 'toast-bottom-left' : 'toast-bottom-right' }}",
                "preventDuplicates": false,
                "showDuration": "3000",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            };
            toastr.warning("<a href='{{ url('/admin/orders') }}'>New Notification</a>");
        }
    });
</script>
