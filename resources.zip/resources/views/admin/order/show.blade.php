@extends('admin.layouts.app')
@section('title') تفاصيل الطلب @endsection
@section('list')
    <ul class="breadcrumb breadcrumb-separatorless fw-bold fs-7 my-1">
        <li class="breadcrumb-item text-muted">
            <a href="{{route('admin.dashboard')}}" class="text-muted text-hover-primary">لوحه التجكم</a>
        </li>
        <li class="breadcrumb-item">
            <span class="bullet bg-gray-200 w-5px h-2px"></span>
        </li>
        <li class="breadcrumb-item text-muted">تفاصيل الطلب</li>
    </ul>
@endsection
@section('content')

    <div class="post d-flex flex-column-fluid" id="kt_post">
        <div id="kt_content_container" class="container-xxl">
            <div class="card">
                <div class="card-header border-0 pt-6">
                    <div class="card-title ">

                    </div>
                    <div class="card-toolbar">
                        <div class="d-flex justify-content-end" data-kt-role-table-toolbar="base">
                            <a href="{{route('admin.print-bill',$order->id)}}" class="btn btn-success btnprn">print</a>
                        </div>
                    </div>
                </div>
                <div class="card-body pt-0">
                    <div class="m-0">
                        <div class="fw-bolder fs-3 text-gray-800 mb-8 text-center ">رقم الطلب :{{$order->id}}</div>
                        <div class="row g-5 mb-11 text-center">
                            <div class="col-sm-6">
                                <div class="fw-bolder fs-7 text-gray-800 mb-1">اسم المحل : {{$order->shop->name}}</div>
                            </div>
                            <div class="col-sm-6">
                                <div class="fw-bolder fs-7 text-gray-800 mb-1">اسم العميل : {{$order->user->name}}</div>
                            </div>
                        </div>
                        <div class="row g-5 mb-12 text-center">
                            <div class="col-sm-6">
                                <div class="fw-bolder fs-7 text-gray-800 mb-1">تاريخ الطلب : {{date('d/m/Y', strtotime($order->created_at))}}</div>
                            </div>
                            <div class="col-sm-6">
                                <div class="fw-bolder fs-6 text-gray-800 mb-1">تاريخ التسليم : {{$order->status == 'تم التسليم' ? date('d/m/Y', strtotime($order->updated_at)) : 'لم يتم التسليم بعد'}}</div>
                            </div>
                        </div>
                        <div class="flex-grow-1">
                            <div class="table-responsive border-bottom mb-9">
                                <table class="table mb-3">
                                    <thead>
                                        <tr class="border-bottom fs-6 fw-bolder text-muted">
                                            <th class="text-center w-10px pe-2">#</th>
                                            <th class="text-center w-10px pe-2"> اسم المنتج </th>
                                            <th class="text-center w-80px">كميه الجملة المطلوبه</th>
                                            <th class="text-center w-80px">كميه القطاعي المطلوبه</th>
                                            <th class="text-center w-80px">المستلم من الجملة</th>
                                            <th class="text-center w-80px">المستلم من القطاعي</th>
                                            <th class="text-center w-80px">المرتجع من الجملة</th>
                                            <th class="text-center w-80px">المرتجع من القطاعي</th>
                                            <th class="text-center w-80px">سعر الوحده جمله</th>
                                            <th class="text-center w-80px">سعر الوحده قطاعى</th>
                                            <th class="text-center w-80px">السعر الكلى</th>
                                            {{-- <th class="text-center w-70px">الاجراءات</th> --}}
                                        </tr>
                                    </thead>
                                    <tbody class="order-table">
                                        @foreach ($order->products as $key=>$product)
                                            <tr class="fw-bolder text-gray-700 fs-5 text-center">
                                                <td class="d-flex align-items-center pt-6">{{$product->id}}</td>
                                                <td class="pt-6">{{$product->name}}</td>
                                                <td class="pt-6"><input class="form-control current_wholesale_quantity" name="current_wholesale_quantity[]" id="{{$product->id}}" value="{{$product->pivot->current_wholesale_quantity}}"></td>
                                                <td class="pt-6"><input {{$product->selling_type == 'جمله فقط' ? 'disabled': ''}} class="form-control current_unit_quantity" id="{{$product->id}}" name="current_unit_quantity[]" value="{{$product->pivot->current_unit_quantity}}"></td>
                                                <td class="pt-6">{{$product->pivot->current_wholesale_quantity}}</td>
                                                <td class="pt-6">{{$product->pivot->current_unit_quantity}}</td>
                                                <td class="pt-6">{{$product->pivot->wholesale_returned_quantity == null ? 0 : $product->pivot->wholesale_returned_quantit}}</td>
                                                <td class="pt-6">{{$product->pivot->unit_returned_quantity == null ? 0 : $product->pivot->unit_returned_quantity}}</td>
                                                <td class="pt-6">{{$product->pivot->wholesale_price}}</td>
                                                <td class="pt-6">{{$product->pivot->unit_price}}</td>
                                                <td class="pt-6">{{$product->pivot->total}}</td>
                                                {{-- <td class="pt-6">
                                                    <button class="btn px-3 delete">
                                                        <i class="fas fa-trash-alt" style="color:red"></i>
                                                    </button>
                                                </td> --}}
                                            </tr>
                                        @endforeach
                                        <tr>
                                            <td class="text-center w-10px pe-2"></td>
                                            <td class="text-center w-10px pe-2"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px">السعر قبل التوصيل</td>
                                            <td class="text-center w-80px">{{$order->sub_total}} جنيه</td>
                                            {{-- <td class="text-center w-80px"></td> --}}
                                        </tr>
                                        <tr>
                                            <td class="text-center w-10px pe-2"></td>
                                            <td class="text-center w-10px pe-2"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px">مصاريف التوصيل </td>
                                            <td class="text-center w-80px">{{$order->fee}} جنيه</td>
                                            {{-- <td class="text-center w-80px"></td> --}}
                                        </tr>
                                        <tr>
                                            <td class="text-center w-10px pe-2"></td>
                                            <td class="text-center w-10px pe-2"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px">المسافه بالكيلو </td>
                                            <td class="text-center w-80px">{{$order->distance}} كيلو</td>
                                            {{-- <td class="text-center w-80px"></td> --}}
                                        </tr>
                                        <tr>
                                            <td class="text-center w-10px pe-2"></td>
                                            <td class="text-center w-10px pe-2"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px">المكافأه الفورى</td>
                                            <td class="text-center w-80px">0</td>
                                            {{-- <td class="text-center w-80px"></td> --}}
                                        </tr>
                                        <tr>
                                            <td class="text-center w-10px pe-2"></td>
                                            <td class="text-center w-10px pe-2"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px">كاش باك</td>
                                            <td class="text-center w-80px">0</td>
                                            {{-- <td class="text-center w-80px"></td> --}}
                                        </tr>
                                        <tr>
                                            <td class="text-center w-10px pe-2"></td>
                                            <td class="text-center w-80px">{{isset($status) ? 'الحاله': ''}}</td>
                                            <td class="text-center w-80px">
                                                @if(isset($status))
                                                    <select name="status" class="form-select form-select-lg mb-3 status">
                                                        @foreach ($status as $state)
                                                            <option value="{{$state}}" {{$order->status == $state ? 'selected' : ''}}>{{$state}}</option>
                                                        @endforeach
                                                    </select>
                                                @else
                                                    <button onclick="confirm({{$order->id}})" class="btn btn-success">تأكيد الطلب</button>
                                                @endif
                                            </td>
                                            <td class="text-center w-80px">
                                                @if(isset($status))
                                                    <button onclick="saveChanges({{$order->id}})" class="btn btn-success">حفظ التغييرات</button>
                                                @else
                                                    <button data-url='/admin/orders/{{$order->id}}' class="btn btn-danger cancel">الفاء الطلب</button>
                                                @endif
                                            </td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px"></td>
                                            <td class="text-center w-80px">الاجمالى </td>
                                            <td class="text-center w-80px">
                                                @if(isset($status))
                                                    {{$order->total}} جنيه
                                                @else
                                                    <input class="form-control total" type="text" name="total" value="{{$order->total}}" >
                                                @endif
                                            </td>
                                            {{-- <td class="text-center w-80px"></td> --}}
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


@section('js')
<script type="text/javascript" src="/assets/js/jquery.printPage.js"></script>
    <script>
        setTimeout(function() {
            $('.flash').fadeOut('fast');
        }, 3000);

        function saveChanges(id){
            wholesale_quantity = [];
            $('.current_wholesale_quantity').each(function(index){
                var input = $(this);
                wholesale_quantity.push([input.attr('id'),input.val()]);
            });
            unit_quantity = [];
            $('.current_unit_quantity').each(function(index){
                var input = $(this);
                unit_quantity.push([input.attr('id'),input.val()]);
            });

            let messages = 'تم تغيير الحاله بنجاح';
            let order_id = id;
            let status   = $('.status :selected').val();
            $.ajax({
                url: "{{url('admin/change-status-order')}}",
                type: 'POST',
                data: {
                    _method : 'POST',
                    _token : '{{ csrf_token() }}',
                    status:status,
                    order_id:order_id,
                    wholesale_quantity:wholesale_quantity,
                    unit_quantity:unit_quantity,
                },
                success: function (res) {
                    if (res.status == false) {
                        alert(res.message)
                    }else{
                        Swal.fire({
                            position: 'top-end',
                            icon: 'success',
                            title:res.message ,
                            showConfirmButton: false,
                            timer: 1500
                        })
                    }
                    getOrderDetails(order_id);
                }
            });
        }
        function confirm(id){
            wholesale_quantity = [];
            $('.current_wholesale_quantity').each(function(index){
                var input = $(this);
                wholesale_quantity.push([input.attr('id'),input.val()]);
            });
            unit_quantity = [];
            $('.current_unit_quantity').each(function(index){
                var input = $(this);
                unit_quantity.push([input.attr('id'),input.val()]);
            });
            let order_id = id;
            let total   = $('.total').val();
            $.ajax({
                url: "{{url('admin/confirm-order')}}",
                type: 'POST',
                data: {
                    _method : 'POST',
                    _token : '{{ csrf_token() }}',
                    total:total,
                    order_id:order_id,
                    wholesale_quantity:wholesale_quantity,
                    unit_quantity:unit_quantity,
                },
                success: function (res) {
                    if (res.status == false) {
                        alert(res.message)
                    }else{
                        Swal.fire({
                            icon: 'success',
                            title: 'تم تأكيد الطلب',
                            showConfirmButton: false,
                            timer: 1500
                        })
                        var baseUrl = window.location.origin;
                        window.location.href =  baseUrl + '/admin/orders';
                    }
                }
            });
        }

        $('.cancel').click(function(event){
            Swal.fire({
                    title: 'هل انت متأكد؟',
                    text: "لن تتمكن من التراجع عن هذا!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'نعم !',
                    cancelButtonText: 'الغاء',
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: $(this).data('url'),
                        type: 'POST',
                        data: {
                            _method : 'DELETE',
                            _token : $('meta[name="csrf-token"]').attr('content')
                        },
                        success: function (res) {
                            console.log(res)
                            if (result.value) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'تم الالغاء',
                                    showConfirmButton: false,
                                    timer: 1500
                                })
                                var baseUrl = window.location.origin;
                                window.location.href =  baseUrl + '/admin/orders';
                            }
                        }
                    });
                }
            })
        });

        function getOrderDetails(id){
            $.ajax({
                url: "/admin/orders/"+id,
                type: 'GET',
                data: {
                    _method : 'GET',
                    _token : '{{ csrf_token() }}',
                    id:id,
                },
                success: function (res) {
                    $('.order-table').html('').append(res);
                }
            });
        }
        $(document).ready(function(){
            $('.btnprn').printPage();
        });

    </script>
@endsection

