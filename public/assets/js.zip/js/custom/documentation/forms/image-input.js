"use strict";

// Class definition
var KTGeneralImageInputDemos = function() {
    // Private functions
    var _exampleBasic = function() {
        
    }

    return {
        // Public Functions
        init: function() {
            _exampleBasic();
        }
    };
}();

// On document ready
KTUtil.onDOMContentLoaded(function() {
    KTGeneralImageInputDemos.init();
});
